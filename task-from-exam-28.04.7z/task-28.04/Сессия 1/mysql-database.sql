CREATE TABLE IF NOT EXISTS `users` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(64) CHARACTER SET 'utf8mb4' NOT NULL,
	`login` VARCHAR(30) CHARACTER SET 'utf8mb4' NOT NULL,
	`password` VARCHAR(30) CHARACTER SET 'utf8mb4' NOT NULL,
	`is_admin` TINYINT(1) NOT NULL, 
	`logged_ip` CHAR(15) CHARACTER SET 'utf8mb4' DEFAULT NULL,
	`logged_date` DATETIME DEFAULT NULL,
	PRIMARY KEY(id)
);

CREATE TABLE IF NOT EXISTS `services` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`title` VARCHAR(128) CHARACTER SET 'utf8mb4' NOT NULL,
	`price` DOUBLE(10,2) NOT NULL,
	`price_unit` VARCHAR(8) CHARACTER SET 'utf8mb4' NOT NULL,
	`time_in_seconds` INT(8) NOT NULL,
	PRIMARY KEY(id)
);

CREATE TABLE IF NOT EXISTS `user_service` (
	`id` INT(10) NOT NULL AUTO_INCREMENT,
	`user_id` INT(10) NOT NULL,
	`service_id` INT(10) NOT NULL,
	`result_value` DOUBLE(10,7) NOT NULL,
	`result_status` TINYINT(1) NOT NULL,
	`analyzer` VARCHAR(128) CHARACTER SET 'utf8mb4' NOT NULL,
	PRIMARY KEY(id),
	CONSTRAINT `FK_UserService_User`
		FOREIGN KEY (`user_id`)
		REFERENCES `users`(`id`)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION,
	CONSTRAINT `FK_UserService_Service`
		FOREIGN KEY (`service_id`)
		REFERENCES `services`(`id`)
		ON DELETE NO ACTION
		ON UPDATE NO ACTION
);